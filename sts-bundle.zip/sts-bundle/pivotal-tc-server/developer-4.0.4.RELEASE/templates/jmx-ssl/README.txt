Version: 4.0.4.RELEASE
Build Date: 20181128221035

* Updates the JmxSocketListener to use SSL for all JMX communication
* Adds sample certificate and key files that can be used to test the SSL 
configuration
