Version: 4.0.4.RELEASE
Build Date: 20181128221035

* Adds a Blocking IO (BIO) connector for HTTPS
* Adds sample certificate and key files that can be used to test the SSL 
configuration
