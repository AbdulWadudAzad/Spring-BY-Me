Version: 4.0.4.RELEASE
Build Date: 20181128221035

* Add Tomcat 8-specific Servlet 3.1 Specification
* Add Tomcat 8-specific web.xml as a watched resource
