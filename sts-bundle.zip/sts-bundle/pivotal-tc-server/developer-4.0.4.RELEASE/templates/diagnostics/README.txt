Version: 4.0.4.RELEASE
Build Date: 20181128221035

* Adds a JDBC resource that integrates with request diagnostics to report slow 
queries
* Adds a ThreadDiagnosticsValve at the Engine level to report slow running 
requests
