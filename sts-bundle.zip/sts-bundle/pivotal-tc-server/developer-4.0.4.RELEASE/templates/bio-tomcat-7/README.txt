Version: 4.0.4.RELEASE
Build Date: 20181128221035

* Adds a Blocking IO (BIO) connector for HTTP
